package com.example.trabajofinal.navegation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.trabajofinal.models.Alumno
import com.example.trabajofinal.models.AlumnoViewModel
import com.example.trabajofinal.screens.*

@Composable
fun Navegacion(
    isLoading: Boolean,
    onLoginClick: () -> Unit,
    cerrarSesion: () -> Unit,
    verificar: Boolean
) {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = NavRoutes.Login.route) {
        composable(route = NavRoutes.Home.route)
        { AppAlumnos(navController, AlumnoViewModel(),cerrarSesion) }
        composable(route = NavRoutes.AddScreen.route) { AddScreen(navController,cerrarSesion) }
        composable(route = NavRoutes.PlantScreen.route) { PlantScreen(navController, AlumnoViewModel()) }
        composable(route = NavRoutes.MapScreen.route){MapScreen(navController)}
        composable(route = NavRoutes.InfoScreen.route, arguments= listOf(
            navArgument("nombre"){type= NavType.StringType},
            navArgument("descripcion"){type= NavType.StringType},
            navArgument("foto"){type= NavType.StringType}
        )) {
            InfoScreen(
                nombre=it.arguments?.getString("nombre")?:""
                , descripcion =it.arguments?.getString("descripcion")?:""
                , foto = it.arguments?.getString("foto")?:""
                , navController = navController
            )
        }
        composable(NavRoutes.Login.route) {
            if (verificar) {
                LaunchedEffect(key1 = Unit) {
                    navController.navigate(NavRoutes.Home.route){

                        popUpTo(NavRoutes.Login.route) {
                            inclusive = true
                        }

                    }

                }
            }else {
                LoginScreen(
                    isLoading = isLoading,
                    onLoginClick = onLoginClick,
                    verificar = verificar
                )
            }
        }
    }
}