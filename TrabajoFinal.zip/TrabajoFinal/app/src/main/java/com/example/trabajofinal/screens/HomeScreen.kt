package com.example.trabajofinal.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.trabajofinal.R
import com.example.trabajofinal.models.AlumnoViewModel
import com.example.trabajofinal.models.OnBoardingData
import com.example.trabajofinal.navegation.NavRoutes
import com.example.trabajofinal.ui.theme.BottomCardShape
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.HorizontalPager
import com.google.accompanist.pager.PagerState
import com.google.accompanist.pager.rememberPagerState
import kotlinx.coroutines.*

@OptIn(ExperimentalPagerApi::class)
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable

fun AppAlumnos (navController: NavController,
                viewModel: AlumnoViewModel,
                cerrarSesion: () -> Unit) {
    Scaffold(
        topBar = { TopAppBar (backgroundColor = Color.Cyan){
            Spacer(modifier = Modifier
                .width(9.dp)
                .height(5.dp))
            Text(text = "EPS Sena🩺", color = Color.Black,
                modifier = Modifier.clickable{navController.navigate(route = NavRoutes.Home.route)}
            )
            Spacer(modifier = Modifier
                .width(65.dp)
                .height(5.dp))
            Text(text = "Citas🗒️", color = Color.Black,
                modifier = Modifier.clickable{navController.navigate(route = NavRoutes.PlantScreen.route)}
            )
            Spacer(modifier = Modifier
                .width(90.dp)
                .height(5.dp))
            IconButton(onClick = {cerrarSesion
                Handler(Looper.getMainLooper()).postDelayed({
                    navController.navigate(NavRoutes.Login.route)
                },2000)
            }) {
                Icon(imageVector = Icons.Default.ExitToApp,
                    contentDescription = null)
            }

        } }
    ) {
        Box(modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.onPrimary)) {
            Column(modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceAround){
                val items = ArrayList<OnBoardingData>()

                items.add(
                    OnBoardingData(
                        R.drawable.mdg,
                        "Medicos Generales",
                        "Contamos con los mejores medicos con los que pueden contar en cualquier momento, ellos te atenderan por cita ya sea de urgencias o agendada.¡Espero seamos de tu ayuda!",
                        colorFondo = Color(0xFF0189C5),
                        principalColor = Color(0xFF00B5EA)
                    )
                )

                items.add(
                    OnBoardingData(
                        R.drawable.sicolos,
                        "Sicologos",
                        "Podras contar siempre con el apoyo de nuestros sicologos y sicologas totalmente gratis, podras agendar cita con ellos y contarles tus problemas, dificultades, etcetera.",
                        colorFondo = Color(0xFFE4AF19),
                        principalColor = Color.Yellow
                    )
                )

                items.add(
                    OnBoardingData(
                        R.drawable.dentista,
                        "Dentistas",
                        "Nuestros dentistas te diran que tipo de tratamiento necesitas y te ayudaran con las caries, sarro, dolores dentales, dolor de encias entre otras causas por la que acudimos a un medico dentista. Gracias por tu apoyo!",
                        colorFondo = Color(0xFF96E172),
                        principalColor = Color.Green
                    )
                )


                val pagerState = rememberPagerState(
                    initialPage = 0,
                )


                OnBoardingPager(
                    navController,
                    item = items,
                    pagerState = pagerState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(color = Color.Blue),

                    )
            }
        }
    }
}//Fin del la funcion


@DelicateCoroutinesApi
@ExperimentalPagerApi
@Composable
fun OnBoardingPager(
    navController: NavController,
    item: List<OnBoardingData>,
    pagerState: PagerState,
    modifier: Modifier = Modifier,
) {

    Box(modifier = modifier) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            HorizontalPager(state = pagerState, count = 3) { page ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(item[page].colorFondo),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Top
                ) {

                    Image(
                        painter = painterResource(id = item[page].imagenes),
                        contentDescription = item[page].titulo,
                        modifier = Modifier
                            .fillMaxWidth()
                    )


                }
            }

        }

        Box(modifier = Modifier.align(Alignment.BottomCenter)) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp),
                backgroundColor = Color.White,
                elevation = 0.dp,
                shape = BottomCardShape.large
            ) {
                Box() {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        PagerIndicator(items = item, currentPage = pagerState.currentPage, navController = NavController)
                        Text(
                            text = item[pagerState.currentPage].titulo,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 20.dp, end = 30.dp),
//                            color = Color(0xFF292D32),
                            color = item[pagerState.currentPage].principalColor,
                            fontFamily = FontFamily.Serif,
                            textAlign = TextAlign.Right,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Text(
                            text = item[pagerState.currentPage].descripciones,
                            modifier = Modifier.padding(top = 20.dp, start = 40.dp, end = 20.dp),
                            color = Color.Gray,
                            fontFamily = FontFamily.Serif,
                            fontSize = 17.sp,
                            textAlign = TextAlign.Center,
                            fontWeight = FontWeight.ExtraLight
                        )

                    }
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(30.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            if (pagerState.currentPage != 2) {
                                TextButton(onClick = {
                                    navController.navigate(NavRoutes.MapScreen.route)
                                }) {
                                    Text(
                                        text = "Donde estamos ubicados",
                                        color = Color(0xFF292D32),
                                        fontFamily = FontFamily.Serif,
                                        textAlign = TextAlign.Right,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                OutlinedButton(
                                    onClick = {
                                        GlobalScope.launch {
                                            withContext(Dispatchers.Main) {
                                                pagerState.scrollToPage(
                                                    pagerState.currentPage + 1,
                                                    pageOffset = 0f
                                                )
                                            }

                                        }
                                    },
                                    border = BorderStroke(
                                        14.dp,
                                        item[pagerState.currentPage].principalColor
                                    ),
                                    shape = RoundedCornerShape(50), // = 50% percent
                                    //or shape = CircleShape
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = item[pagerState.currentPage].principalColor),
                                    modifier = Modifier.size(65.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(id = R.drawable.baseline_arrow_forward_24),
                                        contentDescription = "",
                                        tint = item[pagerState.currentPage].principalColor,
                                        modifier = Modifier.size(70.dp)
                                    )
                                }
                            } else {
                                Button(
                                    onClick = {
                                        //show home screen
                                        navController.navigate(NavRoutes.AddScreen.route)
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        backgroundColor = item[pagerState.currentPage].principalColor
                                    ),
                                    contentPadding = PaddingValues(vertical = 12.dp),
                                    elevation = ButtonDefaults.elevation(
                                        defaultElevation = 0.dp
                                    )
                                ) {
                                    Text(
                                        text = "Agrega tu cita aqui",
                                        color = Color.White,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

        }
    }
}

@Composable
fun PagerIndicator(
    currentPage: Int, items: List<OnBoardingData>,
    navController: NavController.Companion
) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.padding(top = 20.dp)
    ) {
        repeat(items.size) {
            Indicator(isSelected = it == currentPage, color = items[it].principalColor)
        }
    }
}

@Composable
fun Indicator(isSelected: Boolean, color: Color) {
    val width = animateDpAsState(targetValue = if (isSelected) 40.dp else 10.dp)

    Box(
        modifier = Modifier
            .padding(4.dp)
            .height(10.dp)
            .width(width.value)
            .clip(CircleShape)
            .background(
                if (isSelected) color else Color.Gray.copy(alpha = 0.5f)
            )
    )
}


