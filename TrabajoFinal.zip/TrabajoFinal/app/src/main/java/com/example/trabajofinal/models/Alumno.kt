package com.example.trabajofinal.models

data class Alumno(
    val nombre: String = "",
    val descripcion: String = "",
    val foto: String = ""
)