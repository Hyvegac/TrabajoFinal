package com.example.trabajofinal.ui.theme

import androidx.compose.ui.graphics.Color

val ColorBlue = Color(0xFF0D47A1)
val ColorYellow = Color(0xFFFAD206)
val ColorGreen = Color(0xFF80DD65)

val Purple200 = Color(0xFFBB86FC)
val Purple500 = Color(0xFF4ADDEB)
val Purple700 = Color(0xFF3700B3)
val Teal200 = Color(0xFF2196F3)
val Green200 = Color(0xFF8FCA84)

//nuevos colores
val Yellow400 = Color(0xFFFFC000)
val Yellow500 = Color(0xFFFFDE03)
val Blue700 = Color(0xFF0336FF)
val Blue800 = Color(0xFF0035C9)
val Pink500 = Color(0xFFFF0266)
val Pink600 = Color(0xFFD8004D)