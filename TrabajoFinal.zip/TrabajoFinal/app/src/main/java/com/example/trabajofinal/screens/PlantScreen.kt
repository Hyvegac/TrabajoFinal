package com.example.trabajofinal.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.*
import androidx.compose.material.MaterialTheme.shapes
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.trabajofinal.models.Alumno
import com.example.trabajofinal.models.AlumnoViewModel
import com.example.trabajofinal.navegation.NavRoutes

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun PlantScreen(navController: NavController, viewModel: AlumnoViewModel) {
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colors.primary)
                    .border(1.dp, color = Color.Black)
            ) {
                Text(
                    text = "EPS SENA",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 34.sp,
                    color = Color.Black
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(NavRoutes.Home.route) }
                    ) {
                        Text(
                            text = "AGREGAR", color = MaterialTheme.colors.background
                        )
                    } // Fin Column
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(NavRoutes.PlantScreen.route) }

                    ) {
                        Text(
                            text = "MIS CITAS",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        ) // Fin Text
                    } // Fin Column
                } // Fin Row
            } // Fin Column Principal
        } // Fin topBar
    ) // Fin Scaffold
    {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colors.primary)
        ) {
            Column {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2)
                ) {
                    items(viewModel.alumnos.value) { alumno ->
                        Alumnos_Card(alumno, navController)
                    }
                } // Fin LazyColumn
            } // Fin Column-Box
        } // Fin Box
    } //Fin Scaffold
} // Fin JardinLista

@Composable
fun Alumnos_Card(alumno: Alumno, navController: NavController) {
    Card(
        modifier = Modifier
            .padding(all = 16.dp)
            .fillMaxSize()
            .border(3.dp, color = Color.Black, shapes.small)
            .clickable {
                navController.navigate(
                    NavRoutes.InfoScreen.NuevaRuta(
                        alumno.nombre,
                        alumno.descripcion,
                        alumno.foto
                    )
                )
            } // Fin clickable
    ) //Fin Card
    {
        Column(
            modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = alumno.nombre,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(5.dp),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
            )
            Text(
                text = alumno.descripcion,
                color = Color.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(5.dp),
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
            )
            Image(
                painter = rememberAsyncImagePainter(alumno.foto),
                contentDescription = "",
                modifier = Modifier.size(200.dp)
            )//Fin Image
        } // Fin Column
    } // Fin Card
} // Fin PlantaCard