package com.example.trabajofinal.navegation

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class NavRoutes(val route:String) {
    object Alumnos_Card : NavRoutes("Alumnos_Card")
    object Login : NavRoutes("LoginScreen")
    object Home : NavRoutes(route = "AppAlumnos")
    object MapScreen : NavRoutes(route = "MapScreen")
    object AddScreen : NavRoutes(route = "AddScreen")
    object PlantScreen : NavRoutes(route = "PlantScreen")
    object InfoScreen : NavRoutes(route = "InfoScreen/{nombre}/{descripcion}/{foto}") {
        fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
        fun NuevaRuta(nombre: String, descripcion: String,foto: String): String {
            return "InfoScreen/$nombre/$descripcion/${foto.encodeUrl()}"
        }// Fin new_route
    } // Fin InformacionPlanta
}
