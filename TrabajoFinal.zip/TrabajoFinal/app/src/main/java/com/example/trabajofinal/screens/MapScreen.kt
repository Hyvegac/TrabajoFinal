package com.example.trabajofinal.screens

import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.trabajofinal.navegation.NavRoutes
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun MapScreen(navController: NavController) {
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colors.primary)
                    .border(1.dp, color = Color.Black)
            ) {
                Text(
                    text = "EPS SENA",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 34.sp,
                    color = Color.Black
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(NavRoutes.Home.route) }
                    ) {
                        Text(
                            text = "AGREGAR", color = MaterialTheme.colors.background
                        )
                    } // Fin Column
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(NavRoutes.PlantScreen.route) }

                    ) {
                        Text(
                            text = "MIS CITAS",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        ) // Fin Text
                    } // Fin Column
                } // Fin Row
            } // Fin Column Principal
        } // Fin topBar
    ){ // Fin Scaffold {
        Column(modifier = Modifier.padding(all = 8.dp)) {
            var marker = LatLng(4.6957037, -74.214076)
            var uiSettings by remember {
                mutableStateOf(
                    MapUiSettings(
                        mapToolbarEnabled = true,
                        rotationGesturesEnabled = true
                    )
                )
            }
            var properties by remember {
                mutableStateOf(MapProperties(
                    mapType = MapType.HYBRID),
                )
            }
            Text(modifier = Modifier.fillMaxWidth(), text = "Mapa General")
            Spacer(modifier = Modifier.height(6.dp))
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                properties = properties,
                uiSettings = uiSettings
            ) {
                Marker(state = MarkerState(position = marker))
            }
            Spacer(modifier = Modifier.height(6.dp))
        }
    }
}