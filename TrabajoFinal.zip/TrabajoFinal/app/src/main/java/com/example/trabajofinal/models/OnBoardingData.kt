package com.example.trabajofinal.models

import androidx.compose.ui.graphics.Color

data class OnBoardingData(
    val imagenes: Int,
    val titulo: String,
    val descripciones: String,
    val colorFondo: Color,
    val principalColor: Color = Color.Blue
)