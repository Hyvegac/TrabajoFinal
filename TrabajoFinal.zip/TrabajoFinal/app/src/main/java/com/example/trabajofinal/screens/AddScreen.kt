package com.example.trabajofinal.screens

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.trabajofinal.models.Alumno
import com.example.trabajofinal.navegation.NavRoutes
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun AddScreen (navController: NavController, cerrarSesion: () -> Unit) {
    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colors.primary)
                    .border(1.dp, color = Color.Black)
            ) {
                Text(
                    text = "EPS SENA",
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                    fontSize = 34.sp,
                    color = Color.Black
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(NavRoutes.Home.route) }
                    ) {
                        Text(
                            text = "AGREGAR", color = MaterialTheme.colors.background
                        )
                    } // Fin Column
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { navController.navigate(NavRoutes.PlantScreen.route) }

                    ) {
                        Text(
                            text = "MIS CITAS",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        ) // Fin Text
                    } // Fin Column
                } // Fin Row
            } // Fin Column Principal
        } // Fin topBar
    // Fin Scaffold
    ) {
        BodyContent(navController)
    }
}//FIN DE LA FUNCION
@Composable
fun BodyContent (navController: NavController){
    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var foto by remember { mutableStateOf("") }
    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn() {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(all = 20.dp)
                ) {

                    TextField(modifier = Modifier.fillMaxWidth(),
                        value = nombre,
                        onValueChange = { nombre = it },
                        label = { Text("Nombre") }
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    TextField(modifier = Modifier.fillMaxWidth(),
                        value = descripcion,
                        onValueChange = { descripcion = it },
                        label = { Text("Descripcion de la cita") }
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    TextField(modifier = Modifier.fillMaxWidth(),
                        value = foto,
                        onValueChange = { foto = it },
                        label = { Text("Imagen del estudiante") }
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = {
                            val alumno = Alumno(nombre, descripcion,foto)

                            Firebase.firestore.collection("alumnos").add(alumno)
                        },
                        modifier = Modifier
                            .align(Alignment.CenterHorizontally)
                            .padding(vertical = 8.dp)
                            .fillMaxWidth()

                    ) {
                        Text(text = "Agregar Cita")
                    }
                }
            }
        }
    }
}
